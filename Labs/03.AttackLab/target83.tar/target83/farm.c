/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_127()
{
    return 3347664048U;
}

unsigned getval_386()
{
    return 1488860422U;
}

unsigned addval_142(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_420()
{
    return 2425394264U;
}

unsigned getval_444()
{
    return 3347663094U;
}

unsigned addval_165(unsigned x)
{
    return x + 2428995914U;
}

void setval_201(unsigned *p)
{
    *p = 2425444426U;
}

unsigned getval_404()
{
    return 4005793880U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_221()
{
    return 3281309321U;
}

void setval_147(unsigned *p)
{
    *p = 3531132553U;
}

unsigned addval_321(unsigned x)
{
    return x + 3224948361U;
}

unsigned getval_102()
{
    return 3221803393U;
}

unsigned getval_307()
{
    return 2430634312U;
}

unsigned addval_137(unsigned x)
{
    return x + 532860553U;
}

unsigned addval_491(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_299()
{
    return 3221279113U;
}

unsigned getval_373()
{
    return 2425668233U;
}

unsigned getval_305()
{
    return 3674788235U;
}

void setval_320(unsigned *p)
{
    *p = 3281309321U;
}

unsigned getval_385()
{
    return 2430634312U;
}

unsigned getval_116()
{
    return 2495861121U;
}

unsigned getval_391()
{
    return 2425668233U;
}

void setval_234(unsigned *p)
{
    *p = 3525886601U;
}

unsigned getval_313()
{
    return 3224948363U;
}

unsigned addval_480(unsigned x)
{
    return x + 3687039625U;
}

void setval_247(unsigned *p)
{
    *p = 3380920968U;
}

unsigned getval_216()
{
    return 3286272330U;
}

unsigned getval_225()
{
    return 3285293343U;
}

unsigned getval_454()
{
    return 3677933193U;
}

unsigned addval_445(unsigned x)
{
    return x + 3674788233U;
}

unsigned getval_400()
{
    return 3372798345U;
}

unsigned getval_464()
{
    return 3767093671U;
}

unsigned getval_108()
{
    return 3284310390U;
}

void setval_393(unsigned *p)
{
    *p = 3286272344U;
}

unsigned addval_341(unsigned x)
{
    return x + 3375940225U;
}

void setval_156(unsigned *p)
{
    *p = 3531915913U;
}

void setval_463(unsigned *p)
{
    *p = 2425475465U;
}

unsigned getval_121()
{
    return 2425671305U;
}

void setval_136(unsigned *p)
{
    *p = 3252717896U;
}

unsigned addval_369(unsigned x)
{
    return x + 2430632264U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
